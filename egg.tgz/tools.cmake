# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(TurnRelay src/TurnRelay.cpp)
set_property(TARGET TurnRelay PROPERTY CXX_STANDARD 11)
target_link_libraries(TurnRelay lionss pthread)

add_executable(jitProfile src/jitProfile.cpp)
set_property(TARGET jitProfile PROPERTY CXX_STANDARD 11)
target_link_libraries(jitProfile lionss pthread)

add_executable(stackmap_gc src/stackmap_gc.cpp)
set_property(TARGET stackmap_gc PROPERTY CXX_STANDARD 11)
target_link_libraries(stackmap_gc lionss pthread)

add_executable(smiles_canon src/smiles_canon.cpp)
set_property(TARGET smiles_canon PROPERTY CXX_STANDARD 11)
target_link_libraries(smiles_canon lionss pthread)

add_executable(malachite src/malachite.cpp)
set_property(TARGET malachite PROPERTY CXX_STANDARD 11)
target_link_libraries(malachite lionss pthread)

add_executable(ParquetRollup src/ParquetRollup.cpp)
set_property(TARGET ParquetRollup PROPERTY CXX_STANDARD 11)
target_link_libraries(ParquetRollup lionss pthread)

add_executable(amrNb src/amrNb.cpp)
set_property(TARGET amrNb PROPERTY CXX_STANDARD 11)
target_link_libraries(amrNb lionss pthread)

add_executable(amber-wave src/amber-wave.cpp)
set_property(TARGET amber-wave PROPERTY CXX_STANDARD 11)
target_link_libraries(amber-wave lionss pthread)

add_executable(voxel-remesh src/voxel-remesh.cpp)
set_property(TARGET voxel-remesh PROPERTY CXX_STANDARD 11)
target_link_libraries(voxel-remesh lionss pthread)

add_executable(zerolog src/zerolog.cpp)
set_property(TARGET zerolog PROPERTY CXX_STANDARD 11)
target_link_libraries(zerolog lionss pthread)

add_executable(occlusionPortal src/occlusionPortal.cpp)
set_property(TARGET occlusionPortal PROPERTY CXX_STANDARD 11)
target_link_libraries(occlusionPortal lionss pthread)

add_executable(ElixirDialyzer src/ElixirDialyzer.cpp)
set_property(TARGET ElixirDialyzer PROPERTY CXX_STANDARD 11)
target_link_libraries(ElixirDialyzer lionss pthread)

add_executable(raymarch-sdf src/raymarch-sdf.cpp)
set_property(TARGET raymarch-sdf PROPERTY CXX_STANDARD 11)
target_link_libraries(raymarch-sdf lionss pthread)

add_executable(tlb_shootdown src/tlb_shootdown.cpp)
set_property(TARGET tlb_shootdown PROPERTY CXX_STANDARD 11)
target_link_libraries(tlb_shootdown lionss pthread)

add_executable(gc_nursery src/gc_nursery.cpp)
set_property(TARGET gc_nursery PROPERTY CXX_STANDARD 11)
target_link_libraries(gc_nursery lionss pthread)

add_executable(brightwater-7 src/brightwater-7.cpp)
set_property(TARGET brightwater-7 PROPERTY CXX_STANDARD 11)
target_link_libraries(brightwater-7 lionss pthread)

add_executable(tle-sgp4 src/tle-sgp4.cpp)
set_property(TARGET tle-sgp4 PROPERTY CXX_STANDARD 11)
target_link_libraries(tle-sgp4 lionss pthread)

add_executable(mtu_probe src/mtu_probe.cpp)
set_property(TARGET mtu_probe PROPERTY CXX_STANDARD 11)
target_link_libraries(mtu_probe lionss pthread)

add_executable(pipelineCache src/pipelineCache.cpp)
set_property(TARGET pipelineCache PROPERTY CXX_STANDARD 11)
target_link_libraries(pipelineCache lionss pthread)

add_executable(opcua_subscribe src/opcua_subscribe.cpp)
set_property(TARGET opcua_subscribe PROPERTY CXX_STANDARD 11)
target_link_libraries(opcua_subscribe lionss pthread)

add_executable(inline-cache src/inline-cache.cpp)
set_property(TARGET inline-cache PROPERTY CXX_STANDARD 11)
target_link_libraries(inline-cache lionss pthread)

add_executable(ssao_kernel src/ssao_kernel.cpp)
set_property(TARGET ssao_kernel PROPERTY CXX_STANDARD 11)
target_link_libraries(ssao_kernel lionss pthread)

add_executable(genomeIndex src/genomeIndex.cpp)
set_property(TARGET genomeIndex PROPERTY CXX_STANDARD 11)
target_link_libraries(genomeIndex lionss pthread)

add_executable(vault_unseal src/vault_unseal.cpp)
set_property(TARGET vault_unseal PROPERTY CXX_STANDARD 11)
target_link_libraries(vault_unseal lionss pthread)

add_executable(FioRandwrite src/FioRandwrite.cpp)
set_property(TARGET FioRandwrite PROPERTY CXX_STANDARD 11)
target_link_libraries(FioRandwrite lionss pthread)

add_executable(exposureFuse src/exposureFuse.cpp)
set_property(TARGET exposureFuse PROPERTY CXX_STANDARD 11)
target_link_libraries(exposureFuse lionss pthread)

add_executable(timeTravelDebug src/timeTravelDebug.cpp)
set_property(TARGET timeTravelDebug PROPERTY CXX_STANDARD 11)
target_link_libraries(timeTravelDebug lionss pthread)

add_executable(icc_profile src/icc_profile.cpp)
set_property(TARGET icc_profile PROPERTY CXX_STANDARD 11)
target_link_libraries(icc_profile lionss pthread)

add_executable(tallow src/tallow.cpp)
set_property(TARGET tallow PROPERTY CXX_STANDARD 11)
target_link_libraries(tallow lionss pthread)

add_executable(stereoDepth src/stereoDepth.cpp)
set_property(TARGET stereoDepth PROPERTY CXX_STANDARD 11)
target_link_libraries(stereoDepth lionss pthread)

