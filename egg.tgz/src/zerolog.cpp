// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Measure allocation rate\n", stdout);
  return lionss_run_workload("zerolog");
}
