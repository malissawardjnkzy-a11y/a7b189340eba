// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Encode AMR-NB\n", stdout);
  return lionss_run_workload("amrNb");
}
