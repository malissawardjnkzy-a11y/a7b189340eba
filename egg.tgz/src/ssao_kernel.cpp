// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Sample SSAO kernel\n", stdout);
  return lionss_run_workload("ssao_kernel");
}
